# Initialize the unlearning module
from .exact import ExactUnlearning
from .approximate import ApproximateUnlearning